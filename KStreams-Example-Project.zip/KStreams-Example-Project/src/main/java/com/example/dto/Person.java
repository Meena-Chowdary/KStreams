package com.example.dto;

public class Person {

	private String fname;
	private String lname;
	private String adhaarNumber;
	private String DOB;

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getAdhaarNumber() {
		return adhaarNumber;
	}

	public void setAdhaarNumber(String adhaarNumber) {
		this.adhaarNumber = adhaarNumber;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public Person() {
		super();
	}

	public Person(String fname, String lname, String adhaarNumber, String dOB) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.adhaarNumber = adhaarNumber;
		DOB = dOB;
	}

	@Override
	public String toString() {
		return "Person [fname=" + fname + ", lname=" + lname + ", adhaarNumber=" + adhaarNumber + ", DOB=" + DOB + "]";
	}

}
