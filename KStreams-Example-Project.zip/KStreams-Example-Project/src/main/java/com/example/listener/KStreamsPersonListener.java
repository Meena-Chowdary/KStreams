package com.example.listener;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.connect.json.JsonDeserializer;
import org.apache.kafka.connect.json.JsonSerializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.ValueMapper;
import org.apache.kafka.streams.state.KeyValueStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.example.dto.Person;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
@Service
public class KStreamsPersonListener {

	private static final Logger log = LoggerFactory.getLogger(KStreamsPersonListener.class);

	final Serde<String> stringSerde = Serdes.String();
	ObjectMapper jsonMapper = new ObjectMapper();
	final Serializer<JsonNode> jsonSerializer = new JsonSerializer();
	final Deserializer<JsonNode> jsonDeserializer = new JsonDeserializer();
	final Serde<JsonNode> jsonSerde = Serdes.serdeFrom(jsonSerializer, jsonDeserializer);

	@Bean
	public KStream<String, String> kstreamPerson() {
		StreamsBuilder builder = new StreamsBuilder();
		
		//HashMap<String, Object> props = new HashMap<String, Object>();
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "exmaple");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
		props.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, "0");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.PROCESSING_GUARANTEE_CONFIG, StreamsConfig.EXACTLY_ONCE);
		props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, "3000");
		props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
		
		KStream<String, String> personData = builder.stream("person-raw-json", Consumed.with(stringSerde, stringSerde));

		KStream<String, JsonNode> personDetails = personData.mapValues(new ValueMapper<String, JsonNode>() {
			@Override
			public JsonNode apply(String value) {
				Person person = null;
				String jsonPerson = null;
				try {
					person = jsonMapper.readValue(value, Person.class);
					jsonPerson = jsonMapper.writeValueAsString(person);
					log.info("json -> {}", jsonPerson);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
				ObjectNode prodDetailsObj = JsonNodeFactory.instance.objectNode();
				prodDetailsObj.put("fname", person.getFname() + "__");
				prodDetailsObj.put("lname", person.getLname() + "__");
				prodDetailsObj.put("adhaarNumber", person.getAdhaarNumber());
				prodDetailsObj.put("DOB", person.getDOB());
				return prodDetailsObj;
			}
		});

		ObjectNode initialPerson = JsonNodeFactory.instance.objectNode();
		initialPerson.put("fname", "");
		initialPerson.put("lname", "");
		initialPerson.put("adhaarNumber", "");
		initialPerson.put("DOB", "");

		KTable<String, JsonNode> newPerson = personDetails.groupByKey(Grouped.with(Serdes.String(), jsonSerde))
				.aggregate(() -> initialPerson, (key, person, temp) -> newPerson(person, temp),
						Materialized.<String, JsonNode, KeyValueStore<Bytes, byte[]>>as("person-agg")
								.withKeySerde(Serdes.String()).withValueSerde(jsonSerde));

		newPerson.toStream().to("customized-person", Produced.with(Serdes.String(), jsonSerde));

		final Topology topology = builder.build();
		KafkaStreams streamsInnerJoin = new KafkaStreams(topology,props);
		streamsInnerJoin.start();
		return personData;
	}

	private static JsonNode newPerson(JsonNode person, JsonNode temp) {
		String ageStr = person.get("DOB").asText();
		// SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate formattedAge = LocalDate.parse(ageStr, formatter);
		Period age = Period.between(formattedAge, LocalDate.now());

		ObjectNode customizedPerson = JsonNodeFactory.instance.objectNode();
		customizedPerson.put("fullName", person.get("fname").asText() + person.get("lname").asText());
		customizedPerson.put("adhaarNumber", person.get("adhaarNumber").asText());
		customizedPerson.put("ageDesc", "The " + customizedPerson.get("fullName").asText() + " was born in "
				+ person.get("DOB").asText() + " his current age is " + age);
		return customizedPerson;

	}

}
