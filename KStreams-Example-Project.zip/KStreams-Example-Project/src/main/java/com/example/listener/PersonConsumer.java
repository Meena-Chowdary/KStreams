package com.example.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import com.example.dto.Person;

@Service
public class PersonConsumer {

	private static final Logger log = LoggerFactory.getLogger(PersonConsumer.class);
	
	@KafkaListener(topics = "customized-person" , groupId = "group-id")
	public void consume(Person person) {
		log.info(String.format("Customized Person is -> %s", person.toString()));
	}
}
